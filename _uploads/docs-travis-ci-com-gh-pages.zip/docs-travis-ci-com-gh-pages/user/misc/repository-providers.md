---
title: Which Repository Providers Can I Use?
layout: en
permalink: /user/repository-providers/
---

Build and test your open source projects hosted on Github on [travis-ci.org](https://travis-ci.org/).

Build and test your private repositories hosted on Github on [travis-ci.com](https://travis-ci.com/).

Travis CI currently does not support repositories hosted on Bitbucket, Gitlab or Atlassian Stash.
