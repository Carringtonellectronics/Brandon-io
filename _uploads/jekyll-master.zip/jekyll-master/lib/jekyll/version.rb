module Jekyll
  VERSION = "3.4.3".freeze
end
