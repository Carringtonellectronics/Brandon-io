﻿using System.Windows.Controls;

namespace GitHub.UI
{
    public partial class HorizontalShadowDivider: UserControl
    {
        public HorizontalShadowDivider()
        {
            InitializeComponent();
        }
    }
}
