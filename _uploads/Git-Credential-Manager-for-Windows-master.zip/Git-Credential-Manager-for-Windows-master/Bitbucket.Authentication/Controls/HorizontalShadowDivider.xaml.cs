﻿using System.Windows.Controls;

namespace Atlassian.Bitbucket.Authentication.Controls
{
    public partial class HorizontalShadowDivider: UserControl
    {
        public HorizontalShadowDivider()
        {
            InitializeComponent();
        }
    }
}
