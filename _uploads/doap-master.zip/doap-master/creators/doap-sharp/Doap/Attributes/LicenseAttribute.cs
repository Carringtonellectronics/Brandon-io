using System;

namespace Doap.Attributes {

	[AttributeUsage(AttributeTargets.Assembly)]
	public class LicenseAttribute : Attribute {
	}
}
